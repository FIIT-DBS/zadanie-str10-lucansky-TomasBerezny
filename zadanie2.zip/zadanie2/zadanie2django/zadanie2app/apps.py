from django.apps import AppConfig


class Zadanie2AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'zadanie2app'
